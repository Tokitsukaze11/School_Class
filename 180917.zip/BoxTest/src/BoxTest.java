
public class BoxTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box obj1=new Box(10,20,50);
		Box obj2=new Box(10,30,30);
		
		Box largest=obj1.whosLargest(obj1,obj2);
		
		System.out.println("("+largest.width+","+largest.length+","+largest.height+")");
		
		Box largest1,largest2;
		largest1=obj1.whosLargest(obj1,obj2);
		System.out.println("largest1 vo1="+largest1.volume);
		
		largest2=obj2.whosLargest(obj1,obj2);
		System.out.println("largest2 vo2="+largest2.volume);
	
	}

}
