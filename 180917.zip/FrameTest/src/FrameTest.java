import javax.swing.*;
public class FrameTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame f=new JFrame("Frame Test");
		f.setSize(500,300);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setTitle("My New Frame");
		
		
		f.setVisible(true);
	}

}
