
public class SportCarTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SportCar myCar=new SportCar();
		myCar.setSpeed(60);
		myCar.setTurbo(true);
	}

}
