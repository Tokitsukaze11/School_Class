
public class Car {
	int speed;
	
	void setSpeed(int speed) {
		this.speed=speed;
		System.out.println("set speed="+speed);
	}

}
