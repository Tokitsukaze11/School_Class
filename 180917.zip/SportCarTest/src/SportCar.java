
public class SportCar extends Car{
	boolean turbo;
	public void setTurbo(boolean flag) {
		turbo=flag;
		System.out.println("set turbo="+turbo);
	}

}
