
public class Point {
	private int x,y;
	public Point(int a, int b) {
		x=a; y=b;
	}
	
	public String toString() {
		return "point[x="+x+", y="+y+"]";
	}

}
