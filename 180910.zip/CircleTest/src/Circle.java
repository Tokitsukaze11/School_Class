
public class Circle {
	private int radius;
	private Point centre;
	
	public Circle(Point p, int r) {
		centre=p;
		radius=r;
	}
	
	public String toString() {
		return "Circle [radius="+radius+", centre="+centre+"]";
	}
}
