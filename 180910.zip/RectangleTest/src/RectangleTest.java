
public class RectangleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle rect1=new Rectangle();
		System.out.println("----------------------");
		
		Rectangle rect2=new Rectangle(10,20);
		System.out.println("----------------------");
		
		Rectangle rect3=new Rectangle(10,20,100,200);
		System.out.println("----------------------");

	}

}
