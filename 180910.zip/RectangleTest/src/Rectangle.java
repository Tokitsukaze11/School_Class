
public class Rectangle {
	private int x;	private int y;
	private int width;	private int height;
	
	Rectangle(){
		this(1,1);
		System.out.println("Rectangle is called");
	}
	
	Rectangle(int width, int height){
		this(0,0,width,height);
		System.out.println("Rectangle(int,int) is called");
	}

	Rectangle(int x,int y,int width,int height){
		this.x=x; this.y=y; 
		this.width=width; this.height=height;
		System.out.println("Rectangle(int,int,int,int) is called");
		System.out.println("rectangle("+x+","+y+","+width+","+height+")");
	}

}
